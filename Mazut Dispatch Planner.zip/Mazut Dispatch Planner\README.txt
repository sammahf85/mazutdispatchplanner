MAZUT DISPATCH PLANNER
======================

WHAT IS IN THIS FOLDER
  MazutDispatch.html          The program. Double-click it to open it in Chrome / Edge / Firefox.
  driver-setup-page\index.html  The driver phone setup page (for live locations). Put it online once.

START
  1. Double-click MazutDispatch.html.
  2. First time: click OK to load demo data and try it, or go to "4. Depots" and add your depot.
  3. Add trucks (3. Trucks), customers (2. Clients) and orders (1. Orders) – or upload them from Excel.
  4. Open "5. Trip Schedule" and click "Generate trip schedule".

YOUR DATA
  Your data is saved inside the browser on this computer.
  To move it to another computer: Settings -> "Save backup file", then on the other
  computer open MazutDispatch.html -> Settings -> "Restore backup".
  Make a backup regularly.

INTERNET
  The map, address search, Excel upload and live driver locations need internet.
  Planning works offline.

LIVE DRIVER LOCATIONS (one-time setup)
  1. Put driver-setup-page\index.html online (free), for example with GitHub Pages
     or Netlify Drop (app.netlify.com/drop – drag the driver-setup-page folder).
  2. In the program: "Live Drivers" -> "Set up phone" -> paste the page address -> Save.
  3. Click "Send link by WhatsApp" for each driver. The driver taps the link on the phone
     (iPhone or Android) and follows the steps; OwnTracks is set up automatically.
